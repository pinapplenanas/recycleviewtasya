package com.example.viewpager2tasya

class MyFriend (
    val name: String,
    val phone: String,
    val email: String
)